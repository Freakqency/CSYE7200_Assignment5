package edu.neu.coe.csye7200.fp.list

class IntList {

}

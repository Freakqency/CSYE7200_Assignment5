package edu.neu.coe.csye7200.fp.sorting

object Sorting extends App {
  val r = List(Rational(1, 2), Rational(2, 3), Rational(1, 3))
  println(r.sorted)
}

package edu.neu.coe.csye7200

/**
  * @author scalaprof
  */
class Zipper[A, B] {
  def zip(x: Seq[A], y: Seq[B]): Seq[(A, B)] = ???
}

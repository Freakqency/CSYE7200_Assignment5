package edu.neu.coe.csye7200.fp

import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/**
  * @author scalaprof
  */
class ContainerSpec extends AnyFlatSpec with Matchers {

//  val is = Seq(1,1,2,3,5,8,13,21)
//
//  "Container(is)" should "have size 1" in {
//    val container = Container(is)
//    container.size shouldBe 8
//  }
//  it should "have size 2 even numbers" in {
//    val container = Container(is)
//    val filtered = container.withFilter(_ % 2 == 0)
//    var count = 0
//    filtered.foreach({x => count = count+1})
//    count shouldBe 2
//  }
//  it should "have size 2 even numbers part 2" in {
//    val container = Container(is)
//    val filtered = container.filter(_ % 2 == 0)
//    var count = 0
//    filtered.foreach({x => count = count+1})
//    count shouldBe 2
//  }
}

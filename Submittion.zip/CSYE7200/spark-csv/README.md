If you encounter issues with build/importing table parser, just add the lib folder inside
as module library

On Intellij in would be: right click -> Add as library -> Project level: Module library
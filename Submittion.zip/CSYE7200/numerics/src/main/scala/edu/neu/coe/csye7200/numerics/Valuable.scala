package edu.neu.coe.csye7200.numerics

/**
  * @author scalaprof
  */
trait Valuable[X] {
  def get: X
}

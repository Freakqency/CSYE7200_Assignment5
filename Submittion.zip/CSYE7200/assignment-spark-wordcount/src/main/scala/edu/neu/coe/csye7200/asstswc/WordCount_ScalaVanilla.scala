package edu.neu.coe.csye7200.asstswc

object WordCount_ScalaVanilla {
    //Example input list
    //val list: List[String] = List("Hello World", "Hello World", "Hello World", "Hi")
    //Use scala original methods to perform word count
    //Result format should similiar to Map(Hello -> 3, Hi -> 1, World -> 3)
    //hint: you may start with flatMap() then consider the steps to process data in Spark
    def wordCount(list:List[String]): Map[String, Int] = ??? // TO BE IMPLEMENTED
  }
